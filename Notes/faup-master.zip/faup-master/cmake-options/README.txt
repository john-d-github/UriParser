debug: Compile in debug mode
nolua: Compile without lua
webserver: Compiles the webserver

