Available modules are in the 'modules_available' directory. Simply copy them or symlink to 'modules_enabled' to activate them.
