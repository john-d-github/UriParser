#!/bin/bash
gtar -zcv ./faup > faup.tgz
mv faup.tgz faup.spl
