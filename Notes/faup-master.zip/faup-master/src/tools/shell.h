int faup_handle_shell(int argc, char **argv);

