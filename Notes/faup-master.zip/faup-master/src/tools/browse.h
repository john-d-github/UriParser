#ifndef _FAUP_BROWSE_H_
#define _FAUP_BROWSE_H_

int faup_snapshot_browser(char *snapshot_name);

#endif // _FAUP_BROWSE_H_
