Faup is a simple URL Parser.
