#!/usr/bin/python

from pyfaup.faup import Faup

f = Faup()
f = Faup()

